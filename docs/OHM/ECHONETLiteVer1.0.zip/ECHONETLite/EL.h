//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////
#ifndef __EL_H__
#define __EL_H__
#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif
/*
known problems:
 * multi -> broad
 */


// defined
#define ELPORT  3610

#define SEOJ     4
#define DEOJ     7
#define ESV     10
#define OPC     11
#define EPC     12
#define PDC     13
#define EDT     14


#define SET_I   0x60
#define SET_C   0x61
#define GET     0x62
#define INF_REQ 0x63



// EL
#define EL_SEND_PACKET_MAX_SIZE    256
#define EL_RECEIVE_PACKET_MAX_SIZE 256

class EL
{
private:
	byte _multi[4];
	byte _broad[4];

	unsigned char sendPacketSize;
	uint8_t sBuffer[EL_SEND_PACKET_MAX_SIZE];											// send buffer

	EthernetUDP Udp;


public:

	EL();
	void begin(void);

	// sender
	void send( IPAddress toip, byte sBuffer[], int size );
	void sendBroad( byte sBuffer[], int size );
	void sendMulti( byte sBuffer[], int size );

	// reseiver
	int parsePacket(void);
	int read( byte rBuffer[], int size);
	IPAddress remoteIP(void);

};

#endif
//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
