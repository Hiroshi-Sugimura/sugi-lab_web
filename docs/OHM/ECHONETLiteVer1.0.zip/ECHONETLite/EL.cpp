//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////
#include <SPI.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <Udp.h>
#include <EL.h>


EL::EL() {
	sendPacketSize = 0;
    memset(sBuffer, 0, EL_SEND_PACKET_MAX_SIZE);

	_multi[0] = 224;
	_multi[1] = 0;
	_multi[2] = 23;
	_multi[3] = 0;

	_broad[0] = 255;
	_broad[1] = 255;
	_broad[2] = 255;
	_broad[3] = 255;

}

void EL::begin(void) {

	// Udp
	if( Udp.begin( ELPORT ) ) {
		// Serial.println("Reseiver Udp.begin successful.");								// localPort
	}
	else{
		Serial.println("Reseiver Udp.begin failed.");									// localPort
	}


	// �����オ����INF���΂��C�܂��̓v���t�@�C��
	sendPacketSize = 0;
	memset(sBuffer, 0, EL_SEND_PACKET_MAX_SIZE);
	sBuffer[sendPacketSize++] = 0x10;
	sBuffer[sendPacketSize++] = 0x81;
	sBuffer[sendPacketSize++] = 0x00;
	sBuffer[sendPacketSize++] = 0x00;
	sBuffer[sendPacketSize++] = 0x0e;														// node profile
	sBuffer[sendPacketSize++] = 0xf0;
	sBuffer[sendPacketSize++] = 0x01;
	sBuffer[sendPacketSize++] = 0x0e;														// node profile
	sBuffer[sendPacketSize++] = 0xf0;
	sBuffer[sendPacketSize++] = 0x01;
	sBuffer[sendPacketSize++] = 0x74;														// INF
	sBuffer[sendPacketSize++] = 0x01;
	sBuffer[sendPacketSize++] = 0x80;
	sBuffer[sendPacketSize++] = 0x01;
	sBuffer[sendPacketSize++] = 0x30;


	// �q�������錾
	// �{����0ef0����̃f�o�C�X�ʒm�����ׂ������}���`���ł��Ȃ��̂�
	sendMulti( sBuffer, sendPacketSize );

}


////////////////////////////////////////////////////////////////////////////////////////////////////
// sender

// �u���[�h�L���X�g�ɂ�鑗�M
void EL::sendBroad( byte sBuffer[], int size ) {
	if( Udp.beginPacket( _broad, ELPORT) ) {
		// Serial.println("UDP beginPacket(B) Successful.");
		Udp.write( sBuffer, size);
	}

	if( Udp.endPacket() ) {
		// Serial.println("UDP endPacket(B) Successful.");
	}
	else{
		Serial.println("UDP endPacket(B) failed.");
	}
}


// �}���`�ƌ��������ău���[�h�L���X�g�ɂ�鑗�M
// ���̂悤�ɂ��Ă�����Arduino���}���`�Ή������Ƃ��Ɍ݊�����ۂĂ�n�Y
void EL::sendMulti( byte sBuffer[], int size ) {
	sendBroad( sBuffer, size );
}


// IP�w��ɂ�鑗�M
void EL::send( IPAddress toip, byte sBuffer[], int size ) {

	if( Udp.beginPacket( toip, ELPORT) ) {
		// Serial.println("UDP beginPacket Successful.");
		Udp.write( sBuffer, size);
	}else{
		Serial.println("UDP beginPacket failed.");
	}

	if( Udp.endPacket() ) {
		// Serial.println("UDP endPacket Successful.");
	}
	else{
		Serial.println("UDP endPacket failed.");
	}
}




////////////////////////////////////////////////////////////////////////////////////////////////////
// reseiver
int EL::parsePacket(void) {
	return Udp.parsePacket();
}


IPAddress EL::remoteIP(void) {
	return Udp.remoteIP();
}


int EL::read( byte rBuffer[], int size) {
	int packetSize = parsePacket();

	if( packetSize ) {
		Udp.read( rBuffer, size );							// �󂯎�������e�ǂݎ��
	}

	return packetSize;
}


//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
