This is an Arduino library for the ECHONET Lite protocol.

To download. click the DOWNLOADS button, rename the uncompressed folder ECHONETLite. Check that the ECHONETLite folder contains EL.cpp and EL.h. Place the ECHONETLite library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
