//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////


// 基本ライブラリ
var App = require('./App');
var Sil = require('./Sil');

var configfile = '_config.ini';
var IniFile = require('./IniFile');
var ini = IniFile.read(configfile);

// application configration
App.initialize();
App.setLogType(ini['logtype']);
App.setLevel(parseInt(ini['debuglevel']));
App.setLogfilename(ini['logfile']);
App.setTimeStump(ini['timeStump']);

//////////////////////////////////////////////////////////////////////
// メインここから

// 基本ライブラリ
var os = require('os');

var plainHttpServer;
var HTTPport = parseInt( ini['serverPort'], 10);		// INIファイルで設定


// WebSocket server
var WSServer = require('websocket').server;
var webSocketServer; // = new WSServer({httpServer: plainHttpServer});
// var accept = ['localhost', '127.0.0.1', '192.168.0.2'];
var websocket; //  = req.accept( null, req.origin);


// ECHONET Lite
var EL = require('./EL');

// NICリスト
var interfaces = os.networkInterfaces();
var localaddresses = [];
for (k in interfaces) {
	for (k2 in interfaces[k]) {
		var address = interfaces[k][k2];
		if (address.family == 'IPv4' && !address.internal) {
			localaddresses.push(address.address);
		}
	}
};

// オブジェクトリスト，文字列をバイトにマップ
var objList = ini['OBJ'].split(' ').map( function(value, index, array) {
	return Sil.toHexArray(value);
});

console.log(localaddresses);


// 通信ログ確保用のDatabase  (3)
var dbfilename = "ELLog.db"    // (3)
var sqlite3 = require('sqlite3').verbose(); // (3)
var db = new sqlite3.Database(dbfilename); // (3)

//////////////////////////////////////////////////////////////////////    (3)
// DBにテーブルが作られていなければ作る
db.all( 'select * from sqlite_master where tbl_name=\'ellog\';', function( err, rows) {  // (3)
	if( rows.length==0 ) {  // (3)
		console.log( "ellog table ない" ); // (3)

		// pattern 1
		// db.serialize( function() { // (3)
		// db.run('CREATE TABLE ellog (date TEXT, time TEXT, eldata TEXT);'); }); // (3)

		// pattern 2
		db.run('CREATE TABLE ellog (date TEXT, time TEXT, eldata TEXT);'); // (3)
		db.run('commit;');
	}else{ // (3)
		console.log( "ellog table ある" ); // (3)
	} // (3)
}); // (3)


//////////////////////////////////////////////////////////////////////
// local function
//////////////////////////////////////////////////////////////////////
// HTML用のEL表示
function sendWebSocket( websocket, str ) {
	// コネクションあるかい？なければ送信できないよ！
	if( websocket != null ) {      // if( !websocket )では判定できなかった
		if( websocket.readyState == websocket.CONNECTING ) {
			websocket.send(str);
		}
	}
}


// EL受け取った後の処理
EL.initialize( objList, function ( rinfo, els) {

	// データベースに蓄積する   (4)
	var date = Sil.getDateString();
	var time = Sil.getTimeString();

	// 確認用Webページに送る (5)
	sendWebSocket( websocket, date +","+ time +","+ EL.getSeparatedString_ELDATA(els) );

	// データベースに格納する (4)
	db.serialize( function() {
		var q = 'INSERT INTO ellog VALUES(\'' + date + '\',\'' + time + '\', \''+ EL.getSeparatedString_ELDATA(els) + '\');';
		db.run(q);
	});

});


//////////////////////////////////////////////////////////////////////
// HTTP server
var plainHttpServer = Sil.createHTTPServer(HTTPport);


//////////////////////////////////////////////////////////////////////
// WebSocket server
webSocketServer = new WSServer({httpServer: plainHttpServer});

try {
	webSocketServer.on( 'request', function (req) {

		// WebSocketここから
		websocket = req.accept( null, req.origin);

		// メッセージが来たとき
		websocket.on( 'message', function(msg) {
			console.log('"' + msg.utf8Data + '" is recieved from ' + req.origin);

			websocket.send( msg.utf8Data + ' is sended from You and Server.');

			if ( msg.utf8Data === 'Hello') {
				websocket.send( 'Hello!');
			}
		});

		// WebSocketの解放
		websocket.on( 'close', function (code,desc) {
			console.log( 'connection released! :' + code + ' - ' + desc);
		});

		// 最後にWelcomeメッセージ
		websocket.send('log/Welcome to ' + req.origin );

		// ループしながら最近のEL通信をブラウザ側へ送信  (5)
		db.each( 'select * from ellog order by date asc;', function( err, rows) {
			if( err ) {
				console.log( err );
			}

			sendWebSocket( websocket, rows.date +","+ rows.time +","+ rows.eldata );
		});

	});
}catch (e){
	console.log("WebSocket error caught!" + e);
}


App.print(0, 'Server running at http://' + os.hostname() + ':' + HTTPport);


//////////////////////////////////////////////////////////////////////
// 立ち上がったのでONの宣言
EL.sendOPC1( '224.0.23.0', [0x0e,0xf0], [0x05,0xff], 0x60, 0x80, [0x30]);



//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
