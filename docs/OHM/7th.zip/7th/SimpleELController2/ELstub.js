//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
// setup
var App = require('./App');
var Sil = require('./Sil');


var configfile = '_config.ini';
var IniFile = require('./IniFile');
var ini = IniFile.read( configfile );

// application configration
App.setLogType( ini['logtype'] );
App.setLevel( parseInt( ini['debuglevel'] ) );
App.setLogfilename(  ini['logfile'] );
App.setTimeStump(  ini['timeStump'] );


//////////////////////////////////////////////////////////////////////
// EL�ŏ��\��

// ���C����������
App.initialize();
App.setLevel(5);



// ECHONET Lite
var EL = require('./EL');

var elsocket = EL.initialize( function( rinfo, els ) {
	App.println( 3, 'got message from '+ rinfo.address +':'+ rinfo.port);
	App.println( 3, 'data len: '+ rinfo.size + " seoj:"+ els.SEOJ + " deoj:" + els.DEOJ + " edata:" + els.EDATA );

	App.print( 0, els );

	ar = EL.ELDATA2Array( els );
	App.print( 0, ar );


	App.print( 0, EL.facilities );

});



//////////////////////////////////////////////////////////////////////
// �S�ė����オ�����̂ŃR���g���[��ON�̐錾

// type data
App.println( 3, "type data");


// EL.sendBase( '224.0.23.0',  new Buffer([ 0x10, 0x81, 0x00, 0x00, 0x05, 0xff, 0x01, 0x0e, 0xf0, 0x01, 0x63, 0x01, 0xd5, 0x00 ] ));
// EL.sendArray( '224.0.23.0', [ 0x10, 0x81, 0x00, 0x00, 0x05, 0xff, 0x01, 0x0e, 0xf0, 0x01, 0x63, 0x01, 0xd5, 0x00 ] );
// EL.sendOPC1( '224.0.23.0', [0x05,0xff], [0x0e,0xf0], 0x63, 0xd5, 0x00);

EL.search();


/*
EL.send( '224.0.23.0', [0x05,0xff], [0x0e, 0xf0], 0x60, 0x80, 0x30 );
// EL.senddata( '224.0.23.0', [0x05, 0xff], [0x0e, 0xf0], '1081000005ff010ef0016301d500' );
EL.senddata( '224.0.23.0', [0x05, 0xff], [0x0e, 0xf0], [0x63, 0x01, 0xd5, 0x00] );
EL.sendString( '224.0.23.0', '1081000005ff010ef0016301d500' );
*/

// type string
// App.println( 3, "type string");
// EL.send( '224.0.23.0', [0x05,0xff], [0x0e, 0xf0], 0x60, 0x80, 0x30 );
// EL.senddata( '224.0.23.0', [0x05, 0xff], [0x0e, 0xf0], '1081000005ff010ef0016301d500' );
// EL.sendString( '224.0.23.0', '1081000005ff010ef0016301d500' );



//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
