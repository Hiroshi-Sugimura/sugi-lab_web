//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////
// なんか素直に使いやすいのがなかった


//////////////////////////////////////////////////////////////////////
// IniFile

var fs = require('fs');// ファイル用

// constractor
var IniFile = function() {
};


// read
IniFile.read = function( filename ) {

	// console.dir( filename );
	var ret = new Array();

	var data = fs.readFileSync( filename, 'utf8' );

	data.split(/\r?\n/).forEach( function(line) {   // ここから line が一行分のデータとなる
		line = line.replace(';.*', '');   // まずはコメントの取り除き
		if (line == '') {
			// 空行処理しない
			// continue; ないの？
		} else {
			// さて，処理行
			cmd = line.split( /[ ]*=[ ]*/ );
				if( cmd.length == 2 ) {
					ret[ cmd[0] ] = cmd[1];
				}
		}
	});

	return ret;
};


module.exports = IniFile;

//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
