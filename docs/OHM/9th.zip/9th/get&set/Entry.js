//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
// フレームワーク setup
var App = require('./App');
var Sil = require('./Sil');

var configfile = '_config.ini';
var IniFile = require('./IniFile');
var ini = IniFile.read(configfile);

// application configration
App.initialize();
App.setLogType(ini['logtype']);
App.setLevel(parseInt(ini['debuglevel']));
App.setLogfilename(ini['logfile']);
App.setTimeStump(ini['timeStump']);



//////////////////////////////////////////////////////////////////////
// メインここから

// 基本ライブラリ
var os = require('os');

// NICリスト
var interfaces = os.networkInterfaces();
var localaddresses = [];
for (k in interfaces) {
	for (k2 in interfaces[k]) {
		var address = interfaces[k][k2];
		if (address.family == 'IPv4' && !address.internal) {
			localaddresses.push(address.address);
		}
	}
};

var plainHttpServer;   // (1)
var HTTPport = parseInt( ini['serverPort'], 10);

console.log(localaddresses);

//////////////////////////////////////////////////////////////////////
// local function
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// HTTP server
var plainHttpServer = Sil.createHTTPServer(HTTPport);  // (1)
App.print(0, 'Server running at http://' + os.hostname() + ':' + HTTPport);

//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
