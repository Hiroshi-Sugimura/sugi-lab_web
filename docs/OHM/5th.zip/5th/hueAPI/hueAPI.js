//////////////////////////////////////////////////////////////////////
//  $Date:: 2013-09-28 13:03:13 +0900#$
//  $Rev: 5692 $
//  Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////

var hueLibrary = require("node-hue-api");  // npmでnode-hue-apiをインストール  (1)
var HueApi = hueLibrary.HueApi;
var lightState = hueLibrary.lightState;

var devID = "sugimulabo";  // デベロッパID (2)
var lightNumber = 1;  // ランプ番号 (3)

var hueip;  // ブリッジのIPアドレス（自動取得）  (4)
var api;    // APIオブジェクト  (5)

var hue = 0; // 色相 (6)

// Bridgeの検索結果 (7)
var displayBridges = function(bridge) {
    console.log("Hue Bridges Found: " + JSON.stringify(bridge));
    hueip = bridge[0].ipaddress;
    console.log("hue-BridgesIP: "+ hueip);
    api = new HueApi(hueip, devID);
    setTimeout(TimerHue, 2000);
};

// hue操作の結果 (8)
var displayResult = function(result) {
    console.log(JSON.stringify(result, null, lightNumber) + ": " + hue);
};

// hue操作のerror結果 (9)
var displayError = function(err){
    console.error("Error: " + err);
};

// Bridge検索 (10)
hueLibrary.locateBridges().then(displayBridges).fail(displayError).done();

// lightNumberに変更命令 (11)
function TimerHue(){
    var state;  // 色相コントロール用
    if(hue <= 65535){
        state = {"on":true, "hue":hue};
        api.setLightState(lightNumber, state).then(displayResult).fail(displayError).done();

        hue += 1000;
    } else {
        hue = 0;
    }
    setTimeout(TimerHue, 1000);
};

//////////////////////////////////////////////////////////////////////
//  EOF
//////////////////////////////////////////////////////////////////////
