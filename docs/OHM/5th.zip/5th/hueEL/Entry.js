//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
// フレームワーク setup
var App = require('./App');
var Sil = require('./Sil');

var configfile = '_config.ini';
var IniFile = require('./IniFile');
var ini = IniFile.read(configfile);

// application configration
App.initialize();
App.setLogType(ini['logtype']);
App.setLevel(parseInt(ini['debuglevel']));
App.setLogfilename(ini['logfile']);
App.setTimeStump(ini['timeStump']);

//////////////////////////////////////////////////////////////////////
// メインここから

// 基本ライブラリ
var os = require('os');

var plainHttpServer;   // (1)
var HTTPport = parseInt( ini['serverPort'], 10);		// INIファイルで設定 (1)


// WebSocket server (2)
var WSServer = require('websocket').server;
var webSocketServer; // = new WSServer({httpServer: plainHttpServer});
// var accept = ['localhost', '127.0.0.1', '192.168.0.2'];
var websocket; //  = req.accept( null, req.origin);


// ECHONET Lite (3)
var EL = require('./EL');

// hue
var hue = require('./hueControl');  // 事前にnpmでnode-hue-apiをインストールしておく
hue.initialize(ini['hueDevelopper']);

// NICリスト
var interfaces = os.networkInterfaces();
var localaddresses = [];
for (k in interfaces) {
	for (k2 in interfaces[k]) {
		var address = interfaces[k][k2];
		if (address.family == 'IPv4' && !address.internal) {
			localaddresses.push(address.address);
		}
	}
};

// オブジェクトリスト，文字列をバイトにマップ  (3)
var objList = ini['OBJ'].split(' ').map( function(value, index, array) {
	return Sil.toHexArray(value);
});

console.log(localaddresses);

//////////////////////////////////////////////////////////////////////
// local function
//////////////////////////////////////////////////////////////////////

// websocketで文字列を送る (2)
function sendWebSocket(websocket, str) {
	// コネクションあるかい？なければ送信できないよ！
	if (websocket != null) {      // if( !websocket )では判定できなかった
		if (websocket.readyState == websocket.CONNECTING) {
			websocket.send(str);
		} else {
			App.println(3, "sendWebSocket(): websocket is not connecting.");
		}
	} else {
		// App.println( 3, "sendELtoWebSocket(): websocket is null.");
	}
};


// EL受け取った後の処理 (3)
EL.initialize( objList, function ( rinfo, els) {
	// 確認用Webページに送る
	sendWebSocket(websocket, "ellog/" +  EL.getSeparatedString_ELDATA(els) );

	// コントロールする
	console.dir( els );
	var ch = 0;
	switch( els.DEOJ  ) {
	case '029001':
		ch = 1;
		break;

	case '029002':
		ch = 2;
		break;

	case '029003':
		ch = 3;
		break;

	case '0ef001':
	case '0EF001':
		ch = 99;
		break;

	default:
		console.log( "EOJ is not found." );
		return;
		break;
	}

	switch( els.ESV ) {
		//////////////////////////////////////////////////////////////////////
		// Set
	case '60': // SetI
	case '61': // SetC
		epc = els.DETAIL.substr(0,2);

		switch( epc ) {
		case '80':  // 電源セット
			switch( els.DETAILs[epc] ) {
			case '30':
				hue.setHueOn(ch);
				break;

			case '31':
				hue.setHueOff(ch);
				break;

			default:
				return;
				break;
			}
			break;

		case 'c0':  // 色のセット
		case 'C0':  // 色のセット
			var color = Sil.toHexArray( els.DETAILs[epc] );
			hue.setHueRGB(ch, color[0], color[1], color[2] );
			break;

		default:  // 未実装EPC
			console.log( "warning epc: " + epc );
			return;
			break;
		}
		break;

		//////////////////////////////////////////////////////////////////////
		// Get
	case '62': // Get
		epc = els.DETAIL.substr(0,2);

		switch( epc ) {
			// 電源
		case '80':
			if( ch == 99 ) {
				// ノードプロファイルオブジェクト
				EL.sendOPC1( rinfo.address, [0x0EF001], els.SEOJ, 0x72, 0x80, [0x30] );

			}else{
				// ライト
				hue.getHueOnOff( ch, function(state) {
					if( state == 'on' ) {
						var msg = "10810000" + els.DEOJ + els.SEOJ + "7201800130";
						EL.sendString( rinfo.address, msg );
					}else{
						var msg = "10810000" + els.DEOJ + els.SEOJ + "7201800131";
						EL.sendString( rinfo.address, msg );
					}
				});
			}
			break;

			// lighting
		case 'c0': // color
		case 'C0': // color
			hue.getHueRGB( ch, function( r, g, b ) {
				var msg = "10810000" + els.DEOJ + els.SEOJ + "7201C003" + Sil.toHexString(r) + Sil.toHexString(g) + Sil.toHexString(b);
				EL.sendString( rinfo.address, msg );
			} );
			break;

		default:
			console.log( "warning epc: " + epc );
			return;
			break;
		}
		console.dir( els.DETAILs[epc] );
		break;

	default:
		console.log( "ESV is not available." );
		break;
	}
});


//////////////////////////////////////////////////////////////////////
// HTTP server
var plainHttpServer = Sil.createHTTPServer(HTTPport);  // (1)


//////////////////////////////////////////////////////////////////////
// WebSocket server (2)
webSocketServer = new WSServer({ httpServer: plainHttpServer });

try {
	webSocketServer.on('request', function (req) {

		// WebSocketここから
		websocket = req.accept(null, req.origin);

		// メッセージが来たとき
		websocket.on('message', function (msg) {
			var msgtext = msg.utf8Data;
			App.print(3, '"' + msgtext + '" is recieved from ' + req.origin);
			// websocket.send(msgtext + ' is sended from You and Server.');

			var cmdArray = msgtext.split("/");

			console.dir(cmdArray);
			websocket.send("log/" + cmdArray[0] );

			//////////////////////////////////////////////////////////////////////
			// データベース操作でselectの時は実行して，結果を返す
			switch( cmdArray[0] ) {
			case "getAllStatus":
				hue.getHueJSON( function(json) {
					websocket.send( "log/" + JSON.stringify( json ) );
				});
				break;

			case "On":
				hue.setHueOn( parseInt(cmdArray[1]) );
				break;

			case "Off":
				hue.setHueOff( parseInt(cmdArray[1]) );
				break;

			case "W":
				hue.setHueRGB( parseInt(cmdArray[1]), 10, 10, 10 );
				break;

			case "R":
				hue.setHueRGB( parseInt(cmdArray[1]), 10, 0, 0 );
				break;

			case "G":
				hue.setHueRGB( parseInt(cmdArray[1]), 0, 10, 0 );
				break;

			case "B":
				hue.setHueRGB( parseInt(cmdArray[1]), 0, 0, 10 );
				break;

			case "Y":
				hue.setHueRGB( parseInt(cmdArray[1]), 0, 10, 10 );
				break;

			default:
				console.log( "warning: " + msg);
				break;
			}

		});

		// WebSocketの解放
		websocket.on('close', function (code, desc) {
			console.log('connection released! :' + code + ' - ' + desc);
		});

		// 最後にWelcomeメッセージ
		websocket.send('log/Welcome to ' + req.origin);

	});
} catch (e) {
	console.log("WebSocket error caught!" + e);
}


App.print(0, 'Server running at http://' + os.hostname() + ':' + HTTPport);


//////////////////////////////////////////////////////////////////////
// 立ち上がったのでONの宣言 (4)
EL.sendOPC1( '224.0.23.0', [0x0e,0xf0], [0x05,0xff], 0x60, 0x80, [0x30]);



//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
