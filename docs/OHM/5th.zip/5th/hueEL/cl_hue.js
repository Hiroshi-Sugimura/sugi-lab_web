﻿//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////

// HTML内部

// 現在情報
var b_status = document.getElementById('status');

// ELデータ
var b_lighting1text = document.getElementById('lighting1text');
var b_lighting2text = document.getElementById('lighting2text');
var b_lighting3text = document.getElementById('lighting3text');

var ws;  // websocket
var webSocketServer = "ws://localhost:18082";



////////////////////////////////////////////////////////////////////////////////////////////////////
// WebSocket関係
(function () {

	// WebSocketの書き方の違いを吸収するオブジェクト
	if (typeof WebSocket == 'undefined') {
		if (typeof MozWebSocket != 'undefined') {
			WebSocket = MozWebSocket;
		}
	}

	var ws = new WebSocket(webSocketServer);

	// イベントハンドラ登録
	ws.onopen = function () {
		console.log("websocket opened");
		ws.send( "getAllStatus/" );

	};

	// サーバーの接続
	ws.onclose = function (e) {
		console.log( e.data  );
	};

	// Log errors
	ws.onerror = function (e) {
		console.log('WebSocket Error ' + e);
	};

	////////////////////////////////////////////////////////////////////////////////////////////////
	// サーバーからの送信を受け取るとこ
	ws.onmessage = function (e) {
		// サーバーからのデータ例
		// "log/xxxxxxxxxxxxxxxxxxxxxxxxxx"
		// "all/ 0:ffffff 3:010101 10.5:ffffff 19:0101ff"
		console.log( e.data );
		var cmd = e.data.split("/");  // データタイプ
		var opt = cmd[1].split(" ");

		switch ( cmd[0] ) {
		case "log":
			b_status.innerHTML = "log: " + cmd.slice(1);
			break;

		case "ellog":
			switch( opt[3] ) {
			case "029001":
				b_lighting1text.value = cmd.slice(1);
				break;

			case "029002":
				b_lighting2text.value = cmd.slice(1);
				break;

			case "029003":
				b_lighting3text.value = cmd.slice(1);
				break;

			default:
				b_status.innerHTML = "warning: " + cmd.slice(1);
				break;
			}

			break;

		default:
			break;
		}

	};


	test = function (obj) {
		// console.log("call test();");

		opt = obj.value.split(" ");
		// cid to channels
		ws.send( opt[0] + "/" + opt[1] );
	};

}());


////////////////////////////////////////////////////////////////////////////////////////////////////
// HTML，画像などすべて読み込んだ後に実行
window.onload = function () {
	// アノテーションをロードする
	console.dir("win.onload");
};


//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
