//
//  OutSocket.swift
//  SimpleEL
//
//  Created by 杉村博 on 2015/10/02.
//  Copyright © 2015年 杉村博. All rights reserved.
//

import Foundation
import CocoaAsyncSocket

class OutSocket: NSObject, GCDAsyncUdpSocketDelegate {
    
    let PORT:UInt16 = 3610
    var socket:GCDAsyncUdpSocket!
    
    override init(){
        super.init()
    }
    
    func setupConnection(ipaddress: String){
        socket = GCDAsyncUdpSocket(delegate: self, delegateQueue: dispatch_get_main_queue())
        
        do{
            try socket.connectToHost(ipaddress, onPort: PORT)
        }catch{
            // error handling
        }
    }
    
    func sendBinary(udpPacket :NSData) {
        socket.sendData(udpPacket, withTimeout: 2, tag: 0)
    }
    
    func send(message:String){
        let data = message.dataUsingEncoding(NSUTF8StringEncoding)
        socket.sendData(data, withTimeout: 2, tag: 0)
    }
    
    func udpSocket(sock: GCDAsyncUdpSocket!, didConnectToAddress address: NSData!) {
        print("didConnectToAddress");
    }
    
    func udpSocket(sock: GCDAsyncUdpSocket!, didNotConnect error: NSError!) {
        print("didNotConnect \(error)")
    }
    
    func udpSocket(sock: GCDAsyncUdpSocket!, didSendDataWithTag tag: Int) {
        print("didSendDataWithTag")
    }
    
    func udpSocket(sock: GCDAsyncUdpSocket!, didNotSendDataWithTag tag: Int, dueToError error: NSError!) {
        print("didNotSendDataWithTag")
    }
}

