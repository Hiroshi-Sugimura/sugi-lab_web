//
//  InSocket.swift
//  SimpleEL
//
//  Created by 杉村博 on 2015/10/02.
//  Copyright © 2015年 杉村博. All rights reserved.
//

import Foundation
import CocoaAsyncSocket

class InSocket: NSObject, GCDAsyncUdpSocketDelegate {
    
    let IP = "224.0.23.0"
    let PORT:UInt16 = 3610
    var socket:GCDAsyncUdpSocket!
    var rawData = ""
    var cbfunc:((String) -> Void)?
    
    override init(){
        super.init()
    }
    
    func setupConnection( cb:((String) -> Void)? ){
        cbfunc = cb

        socket = GCDAsyncUdpSocket(delegate: self, delegateQueue: dispatch_get_main_queue())
        
        do{
            try socket.bindToPort(PORT)
            try socket.enableBroadcast(true)
            try socket.joinMulticastGroup(IP)
            try socket.beginReceiving()
        }catch{
            // error handling
        }
    }
    
    func udpSocket(sock: GCDAsyncUdpSocket!, didReceiveData data: NSData!, fromAddress address: NSData!,      withFilterContext filterContext: AnyObject!) {
        print("incoming message: \(data)");
    
        if let f = cbfunc {
            f("\(data)")
        }
    }
}



