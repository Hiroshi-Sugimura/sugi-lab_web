//
//  ViewController.swift
//  SimpleEL
//
//  Created by 杉村博 on 10/14/15.
//  Copyright © 2015 杉村博. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var LightIP: UITextField!
    @IBOutlet weak var LightOn: UIButton!
    @IBOutlet weak var LightOff: UIButton!
    
    @IBOutlet weak var AirconIP: UITextField!
    @IBOutlet weak var AirconOn: UIButton!
    @IBOutlet weak var AirconOff: UIButton!
    
    @IBOutlet weak var LogView: UITextView!
    
    var inSocket: InSocket!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        ////////////////////////////////////////////////////////  (1)
        inSocket = InSocket()
        inSocket.setupConnection({ data in
            self.LogView.text = data + "\n" + self.LogView.text
        })
        ////////////////////////////////////////////////////////////
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    ////////////////////////////////////////////////////////////
    // (2) Light
    @IBAction func LightOnTDown(sender: AnyObject) {
        print("Light on")
        
        var binArray = [UInt8(0x10), UInt8(0x81),
            UInt8(0x00), UInt8(0x00),
            UInt8(0x05), UInt8(0xff), UInt8(0x01),
            UInt8(0x02), UInt8(0x90), UInt8(0x01),
            UInt8(0x60), UInt8(0x01),
            UInt8(0x80), UInt8(0x01), UInt8(0x30)]
        
        let outSocket = OutSocket()             // create a Socket to send UDP data
        outSocket.setupConnection(LightIP.text!)
        outSocket.sendBinary(
            NSData(bytes: &binArray,
                length: binArray.count))       // send Binary Data
    }
    
    @IBAction func LightOffTDown(sender: AnyObject) {
        print("Light off")
        
        var binArray = [UInt8(0x10), UInt8(0x81),
            UInt8(0x00), UInt8(0x00),
            UInt8(0x05), UInt8(0xff), UInt8(0x01),
            UInt8(0x02), UInt8(0x90), UInt8(0x01),
            UInt8(0x60), UInt8(0x01),
            UInt8(0x80), UInt8(0x01), UInt8(0x31)]
        
        let outSocket = OutSocket()             // create a Socket to send UDP data
        outSocket.setupConnection(LightIP.text!)
        outSocket.sendBinary(
            NSData(bytes: &binArray,
                length: binArray.count))       // send Binary Data
    }
    ////////////////////////////////////////////////////////////
    
    
    ////////////////////////////////////////////////////////////
    // (3)  Aircon
    @IBAction func AirconOnTDown(sender: AnyObject) {
        print("Aircon on")
        
        var binArray = [UInt8(0x10), UInt8(0x81),
            UInt8(0x00), UInt8(0x00),
            UInt8(0x05), UInt8(0xff), UInt8(0x01),
            UInt8(0x01), UInt8(0x30), UInt8(0x01),
            UInt8(0x60), UInt8(0x01),
            UInt8(0x80), UInt8(0x01), UInt8(0x30)]
        
        let outSocket = OutSocket()             // create a Socket to send UDP data
        outSocket.setupConnection(AirconIP.text!)
        outSocket.sendBinary(
            NSData(bytes: &binArray,
                length: binArray.count))       // send Binary Data
    }
    
    @IBAction func AirconOffTDown(sender: AnyObject) {
        print("Aircon off")
        
        var binArray = [UInt8(0x10), UInt8(0x81),
            UInt8(0x00), UInt8(0x00),
            UInt8(0x05), UInt8(0xff), UInt8(0x01),
            UInt8(0x01), UInt8(0x30), UInt8(0x01),
            UInt8(0x60), UInt8(0x01),
            UInt8(0x80), UInt8(0x01), UInt8(0x31)]
        
        let outSocket = OutSocket()             // create a Socket to send UDP data
        outSocket.setupConnection(AirconIP.text!)
        outSocket.sendBinary(
            NSData(bytes: &binArray,
                length: binArray.count))       // send Binary Data
    }
    ////////////////////////////////////////////////////////////
    
    
}

