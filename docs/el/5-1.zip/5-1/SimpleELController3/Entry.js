//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
// 基本ライブラリ
var App = require('./App');
var Sil = require('./Sil');

var configfile = '_config.ini';
var IniFile = require('./IniFile');
var ini = IniFile.read( configfile );

// application configration
App.initialize();
App.setLogType( ini['logtype'] );
App.setLevel( parseInt( ini['debuglevel'] ) );
App.setLogfilename(  ini['logfile'] );
App.setTimeStump(  ini['timeStump'] );


//////////////////////////////////////////////////////////////////////
// メインここから

// 基本ライブラリ
var os  = require('os');

var plainHttpServer;
var HTTPport = parseInt( ini['serverPort'], 10);		// INIファイルで設定   (1)

// WebSocket server
var WSServer = require('websocket').server;
var webSocketServer; // = new WSServer({httpServer: plainHttpServer});
// var accept = ['localhost', '127.0.0.1', '192.168.0.2'];
var websocket; //  = req.accept( null, req.origin);

// ECHONET Lite
var EL = require('./EL');

// NICリスト
var interfaces = os.networkInterfaces();
var localaddresses = [];
for (k in interfaces) {
	for (k2 in interfaces[k]) {
		var address = interfaces[k][k2];
		if (address.family == 'IPv4' && !address.internal) {
			localaddresses.push(address.address);
		}
	}
};

// オブジェクトリスト，文字列をバイトにマップ
var objList = ini['OBJ'].split(' ').map( function(value, index, array) {
	return Sil.toHexArray(value);
});

console.log(localaddresses);


//////////////////////////////////////////////////////////////////////
// local function
//////////////////////////////////////////////////////////////////////

// websocketで文字列を送る
function sendWebSocket( websocket, str ) {
	// コネクションあるかい？なければ送信できないよ！
	if( websocket != null ) {      // if( !websocket )では判定できなかった
		if( websocket.readyState == websocket.CONNECTING ) {
			websocket.send( str );
		} else {
			App.println( 3, "sendWebSocket(): websocket is not connecting.");
		}
	}else{
		// App.println( 3, "sendELtoWebSocket(): websocket is null.");
	}
};


// HTML用のEL表示
function sendELtoWebSocket( websocket, date, time, srcip, dstip, SEOJ, DEOJ, ESV, OPC, DETAIL ) {

	// App.println( 1, "sendELtoWebSocket() in:  -- " + elstr);
	// App.print( 0, typeof str );

	var sendString = "";
	sendString =  date + ', ' + time + ', '+ srcip + ', ' + dstip + ',';
	// App.print( 0, sendString );

	// ELのデータベースにあれば
	// EOJをDBからとってくるため同期処理
	EL.toEOJStr( DEOJ, function(deoj) {
		EL.toEOJStr( SEOJ, function(seoj) {
			sendString += SEOJ + '(' + seoj + '), ' + DEOJ + '(' + deoj + '), ' + ESV + ', ' + OPC + ', ' + DETAIL;
			// App.println( 1, "sendELtoWebSocket() sendString is " + sendString);
			sendWebSocket( websocket, "log/" + sendString );
		});
	});

};


//////////////////////////////////////////////////////////////////////
// EL受け取った後の処理
EL.initialize( objList, function ( rinfo, els) {
	// 確認
	// App.println( 3, 'from: ' + rinfo.address +':'+ rinfo.port +

	var date = Sil.getDateString();
	var time = Sil.getTimeString();

	sendELtoWebSocket( websocket, date, time, rinfo.address, localaddresses[0], els.SEOJ, els.DEOJ, els.ESV, els.OPC, els.DETAIL );

});




//////////////////////////////////////////////////////////////////////
// HTTP server
var plainHttpServer = Sil.createHTTPServer(HTTPport);			// (2)


//////////////////////////////////////////////////////////////////////
// WebSocket server
webSocketServer = new WSServer({httpServer: plainHttpServer});		// (3)

try {
	webSocketServer.on( 'request', function (req) {

		// WebSocketここから
		websocket = req.accept( null, req.origin);

		// メッセージが来たとき    (4)
		websocket.on( 'message', function(msg) {
			msgtext = msg.utf8Data;
			App.print( 3, '"' + msgtext + '" is recieved from ' + req.origin);
			websocket.send( msgtext + ' is sended from You.');
			var cmdArray = msgtext.split(" ");

			//////////////////////////////////////////////////////////////////////
			// EL操作
			if ( msgtext === 'Search') {
				EL.search();
			}

			// 一般照明		(5)
			if ( msgtext === 'allLightOn') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x02, 0x90], 0x60, 0x80, [0x30] );
			}

			if ( msgtext === 'allLightOff') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x02, 0x90], 0x60, 0x80, [0x31] );
			}

			if ( cmdArray[0] === 'allLightColor') {
				var frame = [0x10, 0x81, 0x00, 0x00, 0x05, 0xFF, 0x01, 0x02, 0x90, 0x01, 0x60, 0x02, 0xC0, 0x03,
							 Sil.toHexArray( cmdArray[1] ),
							 0xB6, 0x01, 0x45];

				EL.sendArray(EL.EL_Multi, Array.prototype.concat.apply([], frame));
			}

			// 家庭用エアコン
			if ( msgtext === 'allAirconOn') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x01, 0x30], 0x60, 0x80, [0x30] );
			}

			if ( cmdArray[0] === 'allAirconOff') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x01, 0x30], 0x60, 0x80, [0x31] );
			}

			// エアコン運転モード設定   (17)
			if ( cmdArray[0] === 'allAirconHeating') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x01, 0x30], 0x60, 0xB0, [0x43] );
			}

			if ( cmdArray[0] === 'allAirconCooling') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x01, 0x30], 0x60, 0xB0, [0x42] );
			}

			// ブラインド
			if ( msgtext === 'allBlindOpen') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x02, 0x60], 0x60, 0xE0, [0x41] );
			}

			if ( cmdArray[0] === 'allBlindClose') {
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x02, 0x60], 0x60, 0xE0, [0x42] );
			}

			if ( cmdArray[0] === 'allBlindSlat') {    // (10)
				EL.sendOPC1( EL.EL_Multi, [0x05,0xFF], [0x02, 0x60], 0x60, 0xE2, [parseInt(cmdArray[1])] );
			}

			// その他
			if ( cmdArray[0] === 'Elsend') {

				// 送信は自分のログも残しておく
				var date = Sil.getDateString();
				var time = Sil.getTimeString();
				var els = EL.parseString( cmdArray[2] );

				EL.sendString( cmdArray[1], cmdArray[2] );
			}
		});

		// WebSocketの解放
		websocket.on( 'close', function (code,desc) {
			console.log( 'connection released! :' + code + ' - ' + desc);
		});

	});
}catch (e){
	console.log("WebSocket error caught!" + e);
}


App.print( 0, 'Server running at http://' + os.hostname() + ':' + HTTPport);


//////////////////////////////////////////////////////////////////////
// 立ち上がったのでONの宣言
EL.sendOPC1( '224.0.23.0', [0x0e,0xf0], [0x05,0xFF], 0x73, 0x80, [0x30]);



//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
