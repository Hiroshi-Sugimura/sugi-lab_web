//////////////////////////////////////////////////////////////////////
//	$Date:: 2013-09-28 13:03:13 +0900#$
//	$Rev: 5692 $
//	Copyright (C) Hiroshi SUGIMURA 2013.09.27 - above.
//////////////////////////////////////////////////////////////////////

var App = require('./App');



//////////////////////////////////////////////////////////////////////
// Sugimura Interface Library

// クラス変数
var Sil = {
};

// 初期化
Sil.initialize = function() {
};


//////////////////////////////////////////////////////////////////////
// クラス関数

Sil.charToInteger = function( chara ) {
	var ret = 0;
	switch (chara) {
	case "0": case "1": case "2": case "3": case "4": case "5": case "6": case "7": case "8": case "9":
		ret = parseInt(chara);
		break;
	case "a": case "A":
		ret = 10;
		break;

	case "b": case "B":
		ret = 11;
		break;

	case "c": case "C":
		ret = 12;
		break;

	case "d": case "D":
		ret = 13;
		break;

	case "e": case "E":
		ret = 14;
		break;

	case "f": case "F":
		ret = 15;
		break;

	default : ret = 0; break;
	}
	return ret;
}

// 1バイトを文字列の16進表現へ（1Byteは必ず2文字にする）
Sil.toHexString = function( byte ) {
	// 文字列0をつなげて，後ろから2文字分スライスする
	return ( ("0" + byte.toString(16)).slice(-2) );
};


// 16進表現の文字列を数値のバイト配列へ
Sil.toHexArray = function( string ) {

	var ret = [];

	for( i=0; i<string.length; i += 2 ) {

		l = string.substr( i, 1 );
		r = string.substr( i+1, 1 );

		ret.push( (Sil.charToInteger(l) * 16) + Sil.charToInteger(r) );
	}

	return ret;
}

// この瞬間の時間を得る
Sil.getDateString = function () {
	var hiduke = new Date();
	var year = hiduke.getFullYear();
	var month = hiduke.getMonth()+1;
	var week = hiduke.getDay();
	var day = hiduke.getDate();
	var yobi= new Array("日","月","火","水","木","金","土");
	return (year + "." + month + "." + day + "." + yobi[week]);
};

// この瞬間の時間を得る
Sil.getTimeString = function () {
	DD = new Date();
	Hours = DD.getHours();
	Minutes = DD.getMinutes();
	Seconds = DD.getSeconds();
	return (Hours + ":" + Minutes + "." + Seconds);
};


// 純粋なWebページサーバーをつくる
Sil.createHTTPServer = function(HTTPport) {
	var fs  = require('fs');
	var path = require('path');
	var http = require('http');
	var url = require('url');
	var plainHttpServer = null;

	try {
		plainHttpServer = http.createServer( function( req, res) {

			// 状態に応じた処理の定義
			var Response = {
				"200":function(file, filename){
					var extname = path.extname(filename);
					var header = {
						"Access-Control-Allow-Origin":"*",
						"Pragma": "no-cache",
						"Cache-Control" : "no-cache"
						}

					res.writeHead(200, header);
					res.write(file, "binary");
					res.end();
				},
				"404":function(){
					res.writeHead(404, {"Content-Type": "text/plain"});
					res.write("404 Not Found\n");
					res.end();
				},
				"500":function(err){
					res.writeHead(500, {"Content-Type": "text/plain"});
					res.write(err + "\n");
					res.end();
				}
			}

			var uri = url.parse(req.url).pathname;
			var filename = path.join(process.cwd(), uri);

			// ファイルをさがして
			fs.exists( filename, function(exists) {
				// console.log( filename + ' ' + exists);

				// ファイルなしなら404
				if( !exists ) {
					Response["404"]();
					return;
				}

				// ファイルあってそれがディレクトリなら
				if (fs.statSync(filename).isDirectory()) {
					filename += '/index.htm';
				}

				fs.readFile(filename, "binary", function(err, file){
					if (err) { Response["500"](err); return ; }
					Response["200"](file, filename);
				});
			});

		}).listen( HTTPport );

		App.println( 3, "HTTPport: " + HTTPport );
	}catch (e){
		console.dir( App );
		// App.print( 0, e );
	}

	return plainHttpServer;
};



module.exports = Sil;

//////////////////////////////////////////////////////////////////////
// EOF
//////////////////////////////////////////////////////////////////////
